#!/usr/bin/env python3
"""Deterministic S2 rule evaluation over admitted immutable Product snapshots."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from enum import Enum

from tools.implementation_contracts import (
    CandidateQuantifier,
    ImplementationEvidenceRule,
    PolicyImplementationExpectation,
    PolicyImplementationExpectationSet,
    _EXPECTATION_ADMISSION_TOKEN,
    _RULE_ADMISSION_TOKEN,
    compute_expectation_digest,
    compute_rule_digest,
    verify_admitted_expectation_set,
    verify_admitted_ruleset,
)
from tools.implementation_matchers import (
    DiscrepancyCode,
    InvalidEvidenceInputError,
    InvalidRuleError,
    MatcherKind,
    evaluate_assertion,
)
from tools.product_corpus_resolver import (
    CorpusResolverError,
    ProductCorpusSnapshot,
    verify_admitted_product_snapshot,
)
from tools.repo_corpus_resolver import glob_to_regex

_DISCREPANCY_CODES = {code.value for code in DiscrepancyCode}


class EvaluatorInputError(ValueError):
    """Raised when an evaluator input is invalid or not an admitted artifact."""


class ImplementationEvidenceVerdict(str, Enum):
    EVIDENCE_FOUND = "EVIDENCE_FOUND"
    EVIDENCE_MISSING = "EVIDENCE_MISSING"
    EVIDENCE_DISCREPANCY = "EVIDENCE_DISCREPANCY"
    RULE_NOT_APPLICABLE = "RULE_NOT_APPLICABLE"


@dataclass(frozen=True)
class EvidenceLocator:
    kind: str
    value: str


@dataclass(frozen=True)
class EvidenceRef:
    repo_path: str
    content_digest: str
    locator: EvidenceLocator
    resolved_node_paths: tuple[str, ...] = ()
    matched_snippet: str | None = None

    def __post_init__(self) -> None:
        if (
            not self.repo_path
            or self.repo_path.startswith("/")
            or "\\" in self.repo_path
            or re.match(r"^[a-zA-Z]:", self.repo_path)
            or any(part in {".", ".."} for part in self.repo_path.split("/"))
            or any(not part for part in self.repo_path.split("/"))
        ):
            raise ValueError("EvidenceRef repo_path must be a normalized relative POSIX path.")
        if not re.fullmatch(r"[0-9a-f]{64}", self.content_digest):
            raise ValueError("EvidenceRef content_digest must be lowercase SHA-256.")
        locator_kinds = {"file_existence", "yaml_path", "json_pointer"}
        if not isinstance(self.locator, EvidenceLocator) or self.locator.kind not in locator_kinds:
            raise ValueError("EvidenceRef locator kind is not supported.")
        if not isinstance(self.locator.value, str):
            raise ValueError("EvidenceRef locator value must be a string.")
        if self.locator.kind == "file_existence" and self.locator.value != self.repo_path:
            raise ValueError("file_existence locator value must equal repo_path.")
        if self.locator.kind == "yaml_path":
            from tools.implementation_matchers import _parse_yaml_path

            try:
                _parse_yaml_path(self.locator.value)
            except InvalidRuleError as exc:
                raise ValueError("EvidenceRef yaml_path locator is invalid.") from exc
        if self.locator.kind == "json_pointer":
            from tools.implementation_matchers import _parse_json_pointer

            try:
                _parse_json_pointer(self.locator.value)
            except InvalidRuleError as exc:
                raise ValueError("EvidenceRef json_pointer locator is invalid.") from exc
        if not isinstance(self.resolved_node_paths, tuple) or any(
            not isinstance(path, str)
            or (path != "" and not path.startswith("/"))
            or re.search(r"~(?![01])", path)
            for path in self.resolved_node_paths
        ):
            raise ValueError("EvidenceRef resolved node paths must be RFC 6901 pointers.")
        if self.locator.kind == "file_existence" and self.resolved_node_paths:
            raise ValueError("file_existence EvidenceRef cannot contain node paths.")
        if self.matched_snippet is not None:
            raise ValueError("Pilot EvidenceRef matched_snippet must be None.")


@dataclass(frozen=True)
class ImplementationVerificationItem:
    expectation_id: str
    expectation_digest: str
    task_id: str
    rule_id: str
    rule_digest: str
    verdict: ImplementationEvidenceVerdict
    evidence_refs: tuple[EvidenceRef, ...]
    discrepancy_details: str | None = None
    applicability_reason: str | None = None
    explanation: str = ""

    def __post_init__(self) -> None:
        if not isinstance(self.verdict, ImplementationEvidenceVerdict):
            raise ValueError("ImplementationVerificationItem verdict is not supported.")
        if not re.fullmatch(r"[0-9a-f]{64}", self.expectation_digest):
            raise ValueError("ImplementationVerificationItem expectation digest is invalid.")
        if not re.fullmatch(r"[0-9a-f]{64}", self.rule_digest):
            raise ValueError("ImplementationVerificationItem rule digest is invalid.")
        if self.verdict is ImplementationEvidenceVerdict.EVIDENCE_FOUND:
            if not self.evidence_refs or self.discrepancy_details is not None or self.applicability_reason is not None:
                raise ValueError("EVIDENCE_FOUND field invariants are violated.")
        elif self.verdict is ImplementationEvidenceVerdict.EVIDENCE_MISSING:
            if self.evidence_refs or self.discrepancy_details is not None or self.applicability_reason is not None:
                raise ValueError("EVIDENCE_MISSING field invariants are violated.")
        elif self.verdict is ImplementationEvidenceVerdict.EVIDENCE_DISCREPANCY:
            if not self.evidence_refs or not self.discrepancy_details or self.applicability_reason is not None:
                raise ValueError("EVIDENCE_DISCREPANCY field invariants are violated.")
            _validate_sanitized_discrepancy(self.discrepancy_details)
        elif self.verdict is ImplementationEvidenceVerdict.RULE_NOT_APPLICABLE:
            if self.evidence_refs or self.discrepancy_details is not None or not self.applicability_reason:
                raise ValueError("RULE_NOT_APPLICABLE field invariants are violated.")


def _validate_sanitized_discrepancy(value: str) -> None:
    try:
        payload = json.loads(value)
    except json.JSONDecodeError as exc:
        raise ValueError("discrepancy_details must be a JSON array.") from exc
    if not isinstance(payload, list) or not payload:
        raise ValueError("discrepancy_details must be a non-empty JSON array.")
    if json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")) != value:
        raise ValueError("discrepancy_details must use compact sorted-key JSON.")
    for entry in payload:
        if not isinstance(entry, dict) or set(entry) != {"repo_path", "code"}:
            raise ValueError("discrepancy_details entries have an invalid shape.")
        if not isinstance(entry["repo_path"], str) or not entry["repo_path"]:
            raise ValueError("discrepancy_details repo_path must be non-empty.")
        if entry["code"] not in _DISCREPANCY_CODES:
            raise ValueError("discrepancy_details code is not supported.")
    paths = [entry["repo_path"] for entry in payload]
    if paths != sorted(paths):
        raise ValueError("discrepancy_details entries must be sorted by repo_path.")
    if len(paths) != len(set(paths)):
        raise ValueError("discrepancy_details must not contain duplicate repo_path values.")


def _candidate_paths(
    selectors: tuple[str, ...], snapshot: ProductCorpusSnapshot
) -> tuple[str, ...]:
    try:
        compiled = tuple(glob_to_regex(selector) for selector in selectors)
    except CorpusResolverError as exc:
        raise EvaluatorInputError("An admitted selector cannot be compiled.") from exc
    paths = {
        path
        for path in snapshot.paths()
        if any(pattern.match(path) for pattern in compiled)
    }
    return tuple(sorted(paths))


def _locator_for(rule: ImplementationEvidenceRule, path: str) -> EvidenceLocator:
    matcher = rule.assertion.matcher
    if matcher is MatcherKind.FILE_EXISTS:
        return EvidenceLocator(kind="file_existence", value=path)
    if matcher in (MatcherKind.YAML_PATH_EXISTS, MatcherKind.YAML_PATH_EQUALS):
        return EvidenceLocator(kind="yaml_path", value=rule.assertion.target_path_expression or "")
    return EvidenceLocator(kind="json_pointer", value=rule.assertion.target_path_expression or "")


def _discrepancy_json(
    failures: list[tuple[str, DiscrepancyCode]],
) -> str:
    payload = [
        {"repo_path": path, "code": code.value}
        for path, code in sorted(failures, key=lambda item: item[0])
    ]
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def evaluate_rule(
    expectation: PolicyImplementationExpectation,
    rule: ImplementationEvidenceRule,
    snapshot: ProductCorpusSnapshot,
) -> ImplementationVerificationItem:
    """Evaluate one admitted rule against one immutable admitted product snapshot."""
    try:
        verify_admitted_product_snapshot(snapshot)
    except CorpusResolverError as exc:
        raise EvaluatorInputError("Product snapshot failed admission integrity checks.") from exc
    if not isinstance(expectation, PolicyImplementationExpectation) or not isinstance(
        rule, ImplementationEvidenceRule
    ):
        raise EvaluatorInputError("Admitted expectation and rule domain values are required.")
    if (
        getattr(expectation, "_admission_token", None)
        is not _EXPECTATION_ADMISSION_TOKEN
        or getattr(rule, "_admission_token", None) is not _RULE_ADMISSION_TOKEN
    ):
        raise EvaluatorInputError("Expectation and rule must pass strict loader admission.")
    try:
        if (
            compute_expectation_digest(expectation) != expectation.expectation_digest
            or compute_rule_digest(rule) != rule.rule_digest
        ):
            raise EvaluatorInputError(
                "Admitted expectation or rule changed after digest verification."
            )
    except Exception as exc:
        if isinstance(exc, EvaluatorInputError):
            raise
        raise EvaluatorInputError("Admitted expectation or rule is invalid.") from exc
    if rule.rule_id not in expectation.verification_rule_ids:
        raise EvaluatorInputError("Rule is not referenced by the expectation.")
    if expectation.task_id != rule.task_id:
        raise EvaluatorInputError("Expectation and rule task identifiers do not match.")
    if rule.evidence_kind not in expectation.expected_evidence_kinds:
        raise EvaluatorInputError("Rule evidence_kind is not allowed by the expectation.")

    if rule.applicability.status.value == "NOT_APPLICABLE":
        return ImplementationVerificationItem(
            expectation_id=expectation.expectation_id,
            expectation_digest=expectation.expectation_digest,
            task_id=expectation.task_id,
            rule_id=rule.rule_id,
            rule_digest=rule.rule_digest,
            verdict=ImplementationEvidenceVerdict.RULE_NOT_APPLICABLE,
            evidence_refs=(),
            applicability_reason=rule.applicability.reason,
        )

    candidate_paths = _candidate_paths(rule.candidate_selectors, snapshot)
    if not candidate_paths:
        return ImplementationVerificationItem(
            expectation_id=expectation.expectation_id,
            expectation_digest=expectation.expectation_digest,
            task_id=expectation.task_id,
            rule_id=rule.rule_id,
            rule_digest=rule.rule_digest,
            verdict=ImplementationEvidenceVerdict.EVIDENCE_MISSING,
            evidence_refs=(),
        )

    matching: list[EvidenceRef] = []
    failing: list[EvidenceRef] = []
    discrepancy_codes: list[tuple[str, DiscrepancyCode]] = []
    for path in candidate_paths:
        corpus_file = snapshot.get_file(path)
        if corpus_file is None:
            raise EvaluatorInputError("Resolved candidate is missing from the admitted snapshot.")
        try:
            result = evaluate_assertion(rule.assertion, corpus_file.content)
        except (InvalidRuleError, InvalidEvidenceInputError) as exc:
            raise EvaluatorInputError("Candidate assertion or evidence input is invalid.") from exc
        ref = EvidenceRef(
            repo_path=path,
            content_digest=corpus_file.content_hash,
            locator=_locator_for(rule, path),
            resolved_node_paths=result.resolved_node_paths,
        )
        if result.passed:
            matching.append(ref)
        else:
            failing.append(ref)
            assert result.discrepancy_code is not None
            discrepancy_codes.append((path, result.discrepancy_code))

    if rule.candidate_quantifier is CandidateQuantifier.ANY:
        selected_refs = tuple(matching) if matching else tuple(failing)
        passed = bool(matching)
    else:
        passed = not failing
        selected_refs = tuple(candidate for candidate in matching + failing) if passed else tuple(failing)

    if passed:
        return ImplementationVerificationItem(
            expectation_id=expectation.expectation_id,
            expectation_digest=expectation.expectation_digest,
            task_id=expectation.task_id,
            rule_id=rule.rule_id,
            rule_digest=rule.rule_digest,
            verdict=ImplementationEvidenceVerdict.EVIDENCE_FOUND,
            evidence_refs=tuple(sorted(selected_refs, key=lambda item: item.repo_path)),
        )
    return ImplementationVerificationItem(
        expectation_id=expectation.expectation_id,
        expectation_digest=expectation.expectation_digest,
        task_id=expectation.task_id,
        rule_id=rule.rule_id,
        rule_digest=rule.rule_digest,
        verdict=ImplementationEvidenceVerdict.EVIDENCE_DISCREPANCY,
        evidence_refs=tuple(sorted(selected_refs, key=lambda item: item.repo_path)),
        discrepancy_details=_discrepancy_json(discrepancy_codes),
    )


def evaluate_expectation_set(
    expectation_set: PolicyImplementationExpectationSet,
    ruleset: object,
    snapshot: ProductCorpusSnapshot,
) -> tuple[ImplementationVerificationItem, ...]:
    """Evaluate every explicit expectation/rule link without task-level roll-up."""
    from tools.implementation_contracts import ContractInputError

    try:
        verify_admitted_expectation_set(expectation_set)
        verify_admitted_ruleset(ruleset)
    except ContractInputError as exc:
        raise EvaluatorInputError("Expectation set or ruleset failed integrity verification.") from exc

    rules_by_id = {rule.rule_id: rule for rule in ruleset.rules}
    results = [
        evaluate_rule(
            expectation,
            rules_by_id[rule_id],
            snapshot,
        )
        for expectation in expectation_set.expectations
        for rule_id in expectation.verification_rule_ids
    ]
    return tuple(
        sorted(
            results,
            key=lambda item: (item.task_id, item.expectation_id, item.rule_id),
        )
    )


__all__ = [
    "EvidenceLocator",
    "EvidenceRef",
    "EvaluatorInputError",
    "ImplementationEvidenceVerdict",
    "ImplementationVerificationItem",
    "evaluate_expectation_set",
    "evaluate_rule",
]