#!/usr/bin/env python3
"""Resolve immutable S2 Product repository snapshots from admitted manifests."""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import re
from pathlib import Path

from tools.repo_corpus_resolver import (
    CorpusFile,
    CorpusResolverError,
    RepoCorpusResolver,
)
from tools.validate_product_target_manifest import (
    ProductTargetManifest,
    parse_product_target_manifest_file,
)

_PRODUCT_SNAPSHOT_TOKEN = object()


def product_snapshot_integrity_digest(
    *,
    manifest_digest: str,
    target_commit: str,
    corpus_digest: str,
    files: tuple[CorpusFile, ...],
) -> str:
    hasher = hashlib.sha256()
    hasher.update(f"manifest\t{manifest_digest}\ncommit\t{target_commit}\n".encode("utf-8"))
    hasher.update(f"corpus\t{corpus_digest}\n".encode("utf-8"))
    corpus_hasher = hashlib.sha256()
    sorted_files = tuple(sorted(files, key=lambda item: item.relative_path))
    if tuple(file.relative_path for file in files) != tuple(
        file.relative_path for file in sorted_files
    ):
        raise CorpusResolverError("Product snapshot files must be sorted by repo path.")
    for file in sorted_files:
        path = file.relative_path
        if (
            not path
            or path.startswith("/")
            or "\\" in path
            or ".." in path.split("/")
            or any(not part for part in path.split("/"))
        ):
            raise CorpusResolverError("Product snapshot contains an invalid repo path.")
        if not re.fullmatch(r"[0-9a-f]{64}", file.content_hash):
            raise CorpusResolverError("Product snapshot file digest is invalid.")
        actual_digest = hashlib.sha256(file.content.encode("utf-8", errors="strict")).hexdigest()
        if actual_digest != file.content_hash:
            raise CorpusResolverError("Product snapshot file content digest mismatch.")
        if len(file.content.encode("utf-8", errors="strict")) != file.byte_size:
            raise CorpusResolverError("Product snapshot file byte_size does not match its content.")
        corpus_hasher.update(f"{path}\t{file.content_hash}\n".encode("utf-8"))
        hasher.update(
            f"{file.relative_path}\t{file.content_hash}\t{file.byte_size}\n".encode("utf-8")
        )
    if corpus_hasher.hexdigest() != corpus_digest:
        raise CorpusResolverError("Product snapshot corpus_digest does not match its files.")
    return hasher.hexdigest()


@dataclass(frozen=True)
class ProductCorpusSnapshot:
    """Immutable Product snapshot carrying S2 manifest and corpus identities."""

    manifest: ProductTargetManifest
    target_commit: str
    files: tuple[CorpusFile, ...]
    total_files: int
    total_bytes: int
    manifest_digest: str
    corpus_digest: str
    _admission_token: object = field(repr=False, compare=False)
    _admission_digest: str = field(repr=False, compare=False)

    def __post_init__(self) -> None:
        if self._admission_token is not _PRODUCT_SNAPSHOT_TOKEN:
            raise CorpusResolverError(
                "Product snapshots must be created by ProductCorpusResolver."
            )
        if type(self.files) is not tuple or any(
            type(file) is not CorpusFile for file in self.files
        ):
            raise CorpusResolverError(
                "Product snapshot files must be an immutable tuple of CorpusFile values."
            )
        if not re.fullmatch(r"[0-9a-f]{40}", self.target_commit):
            raise CorpusResolverError("Product snapshot target_commit must be lowercase full SHA-1.")
        if (
            self.manifest.digest != self.manifest_digest
            or self.manifest.target.commit.lower() != self.target_commit
        ):
            raise CorpusResolverError("Product snapshot identity does not match its manifest.")
        if len(self.files) != self.total_files or sum(file.byte_size for file in self.files) != self.total_bytes:
            raise CorpusResolverError("Product snapshot aggregate file totals are inconsistent.")
        if len({file.relative_path for file in self.files}) != len(self.files):
            raise CorpusResolverError("Product snapshot paths must be unique.")
        expected_admission_digest = product_snapshot_integrity_digest(
            manifest_digest=self.manifest_digest,
            target_commit=self.target_commit,
            corpus_digest=self.corpus_digest,
            files=self.files,
        )
        if self._admission_digest != expected_admission_digest:
            raise CorpusResolverError("Product snapshot contents changed after admission.")

    def paths(self) -> tuple[str, ...]:
        return tuple(file.relative_path for file in self.files)

    def get_file(self, path: str) -> CorpusFile | None:
        normalized = path.replace("\\", "/").strip("/")
        return next(
            (file for file in self.files if file.relative_path == normalized), None
        )


class ProductCorpusResolver:
    """Resolve Product manifests while reusing the S1 Git materializer."""

    def __init__(self, resolver: RepoCorpusResolver | None = None) -> None:
        self._resolver = resolver or RepoCorpusResolver()

    def resolve(
        self,
        manifest: ProductTargetManifest,
        repo_path: Path | str | None = None,
    ) -> ProductCorpusSnapshot:
        resolved_repo_path = Path(repo_path).resolve() if repo_path is not None else None
        if (
            manifest.target.source_type == "local_git"
            and resolved_repo_path is not None
            and Path(manifest.target.repo).resolve() != resolved_repo_path
        ):
            raise CorpusResolverError(
                "Provided repository path does not match the declared local_git target."
            )
        snapshot = self._resolver.resolve(manifest, repo_path=Path(repo_path) if repo_path else None)
        files = snapshot.files
        manifest_digest = manifest.digest
        corpus_digest = snapshot.corpus_digest
        target_commit = snapshot.target_commit
        admission_digest = product_snapshot_integrity_digest(
            manifest_digest=manifest_digest,
            target_commit=target_commit,
            corpus_digest=corpus_digest,
            files=files,
        )
        return ProductCorpusSnapshot(
            manifest=manifest,
            target_commit=target_commit,
            files=files,
            total_files=snapshot.total_files,
            total_bytes=snapshot.total_bytes,
            manifest_digest=manifest_digest,
            corpus_digest=corpus_digest,
            _admission_token=_PRODUCT_SNAPSHOT_TOKEN,
            _admission_digest=admission_digest,
        )


def verify_admitted_product_snapshot(snapshot: object) -> ProductCorpusSnapshot:
    """Revalidate Product snapshot aggregate after it crosses a consumer boundary."""
    if (
        not isinstance(snapshot, ProductCorpusSnapshot)
        or getattr(snapshot, "_admission_token", None) is not _PRODUCT_SNAPSHOT_TOKEN
    ):
        raise CorpusResolverError("An admitted ProductCorpusSnapshot is required.")
    try:
        snapshot.__post_init__()
    except (AttributeError, TypeError, UnicodeError, ValueError) as exc:
        raise CorpusResolverError("Product snapshot failed integrity revalidation.") from exc
    return snapshot


def resolve_product_corpus_from_manifest(
    manifest_path: Path | str,
    repo_path: Path | str | None = None,
) -> ProductCorpusSnapshot:
    """Admit a Product Target Manifest and resolve its fixed-commit snapshot."""
    manifest = parse_product_target_manifest_file(manifest_path)
    return ProductCorpusResolver().resolve(manifest, repo_path=repo_path)


__all__ = [
    "CorpusResolverError",
    "ProductCorpusResolver",
    "ProductCorpusSnapshot",
    "resolve_product_corpus_from_manifest",
    "verify_admitted_product_snapshot",
]