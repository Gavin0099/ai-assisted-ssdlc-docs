from __future__ import annotations

import copy
import os
import subprocess
import unittest
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

from tools.implementation_contracts import (
    CandidateQuantifier,
    ContractInputError,
    ImplementationEvidenceRule,
    PolicyAssessmentIdentity,
    PolicyImplementationExpectation,
    RuleApplicability,
    RuleApplicabilityStatus,
    compute_expectation_digest,
    compute_expectation_set_semantic_digest,
    compute_rule_digest,
    compute_ruleset_semantic_digest,
    load_expectation_set,
    load_ruleset,
)
from tools.implementation_evaluator import (
    EvidenceLocator,
    EvidenceRef,
    EvaluatorInputError,
    ImplementationEvidenceVerdict,
    ImplementationVerificationItem,
    evaluate_expectation_set,
    evaluate_rule,
)
from tools.implementation_matchers import (
    DiscrepancyCode,
    EvidenceAssertion,
    ExpectedScalar,
    ExpectedScalarKind,
    InvalidEvidenceInputError,
    InvalidRuleError,
    MatcherKind,
)
from tools.product_corpus_resolver import CorpusResolverError, ProductCorpusResolver
from tools.validate_product_target_manifest import parse_product_target_manifest
from tests.test_implementation_contracts import make_policy_admission


def run_git(repo_path: Path, *args: str) -> str:
    environment = {
        **os.environ,
        "GIT_AUTHOR_DATE": "2000-01-01T00:00:00+0000",
        "GIT_COMMITTER_DATE": "2000-01-01T00:00:00+0000",
    }
    result = subprocess.run(
        ["git", *args],
        cwd=repo_path,
        env=environment,
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=True,
    )
    return result.stdout.strip()


def make_rule(
    *,
    rule_id: str = "RULE-1",
    task_id: str = "PW.4.4",
    evidence_kind: str = "dependency_lockfile",
    selectors: list[str] | None = None,
    quantifier: str = "ANY",
    matcher: str = "FILE_EXISTS",
    target_path: str | None = None,
    expected_value: dict | None = None,
    applicability: dict | None = None,
) -> ImplementationEvidenceRule:
    assertion_expected = None
    if expected_value is not None:
        assertion_expected = ExpectedScalar(
            ExpectedScalarKind(expected_value["kind"]), expected_value["value"]
        )
    assertion = EvidenceAssertion(
        matcher=MatcherKind(matcher),
        target_path_expression=target_path,
        expected_value=assertion_expected,
    )
    applicability_data = applicability or {"status": "APPLICABLE", "reason": None}
    return ImplementationEvidenceRule(
        rule_id=rule_id,
        rule_digest="0" * 64,
        task_id=task_id,
        evidence_kind=evidence_kind,
        candidate_selectors=tuple(selectors or ["src/**"]),
        candidate_quantifier=CandidateQuantifier(quantifier),
        assertion=assertion,
        applicability=RuleApplicability(
            RuleApplicabilityStatus(applicability_data["status"]),
            applicability_data["reason"],
        ),
    )


def make_admitted_ruleset(rule_value: ImplementationEvidenceRule):
    rule_digest = compute_rule_digest(rule_value)
    canonical_rule = replace(rule_value, rule_digest=rule_digest)
    ruleset_digest = compute_ruleset_semantic_digest((canonical_rule,))
    return load_ruleset(
        {
            "ruleset_version": "1.0",
            "rules": [_rule_to_input(canonical_rule)],
            "ruleset_digest": ruleset_digest,
        }
    )


def _rule_to_input(rule_value: ImplementationEvidenceRule) -> dict:
    expected = rule_value.assertion.expected_value
    return {
        "rule_id": rule_value.rule_id,
        "rule_digest": rule_value.rule_digest,
        "task_id": rule_value.task_id,
        "evidence_kind": rule_value.evidence_kind,
        "candidate_selectors": list(rule_value.candidate_selectors),
        "candidate_quantifier": rule_value.candidate_quantifier.value,
        "assertion": {
            "matcher": rule_value.assertion.matcher.value,
            "target_path_expression": rule_value.assertion.target_path_expression,
            "expected_value": None
            if expected is None
            else {"kind": expected.kind.value, "value": expected.value},
        },
        "applicability": {
            "status": rule_value.applicability.status.value,
            "reason": rule_value.applicability.reason,
        },
    }


def make_admitted_expectations(
    policy_admission,
    rules: tuple[ImplementationEvidenceRule, ...],
    *,
    expectation_specs: tuple[tuple[str, tuple[str, ...]], ...] | None = None,
):
    expectation_specs = expectation_specs or (("EXP-1", (rules[0].rule_id,)),)
    expectation_values = tuple(
        PolicyImplementationExpectation(
            expectation_id=expectation_id,
            expectation_digest="0" * 64,
            task_id="PW.4.4",
            policy_assessment_id=policy_admission.identity.assessment_id,
            policy_finding_id="FIND-1",
            policy_source_ref="policy/dependencies.md#locking",
            expected_evidence_kinds=("dependency_lockfile",),
            verification_rule_ids=rule_ids,
        )
        for expectation_id, rule_ids in expectation_specs
    )
    expectation_values = tuple(
        replace(value, expectation_digest=compute_expectation_digest(value))
        for value in expectation_values
    )
    set_digest = compute_expectation_set_semantic_digest(
        policy_admission.identity, expectation_values
    )
    return load_expectation_set(
        {
            "expectation_set_version": "1.0",
            "policy_assessment_identity": {
                "assessment_id": policy_admission.identity.assessment_id,
                "target_source_type": policy_admission.identity.target_source_type,
                "target_repo": policy_admission.identity.target_repo,
                "target_commit": policy_admission.identity.target_commit,
                "target_manifest_digest": policy_admission.identity.target_manifest_digest,
                "target_corpus_digest": policy_admission.identity.target_corpus_digest,
            },
            "expectations": [
                {
                    "expectation_id": value.expectation_id,
                    "expectation_digest": value.expectation_digest,
                    "task_id": value.task_id,
                    "policy_assessment_id": value.policy_assessment_id,
                    "policy_finding_id": value.policy_finding_id,
                    "policy_source_ref": value.policy_source_ref,
                    "expected_evidence_kinds": list(value.expected_evidence_kinds),
                    "verification_rule_ids": list(value.verification_rule_ids),
                }
                for value in expectation_values
            ],
            "expectation_set_digest": set_digest,
        },
        policy_admission=policy_admission,
        ruleset=load_ruleset(
            {
                "ruleset_version": "1.0",
                "rules": [_rule_to_input(rule) for rule in rules],
                "ruleset_digest": compute_ruleset_semantic_digest(rules),
            }
        ),
    )


class EvaluatorTestBase(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = TemporaryDirectory()
        self.root_dir = Path(self.temp_dir.name)
        self.policy_admission, _assessment_path = make_policy_admission(self.root_dir)
        self.repo_dir = self.root_dir / "product-repo"
        self.repo_dir.mkdir()
        run_git(self.repo_dir, "init", "-b", "main")
        run_git(self.repo_dir, "config", "user.name", "S2 Evaluator")
        run_git(self.repo_dir, "config", "user.email", "s2-evaluator@example.invalid")

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def _snapshot(self, files: dict[str, str]):
        for relative_path, content in files.items():
            path = self.repo_dir / relative_path
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
        run_git(self.repo_dir, "add", ".")
        run_git(self.repo_dir, "commit", "-m", "add product evidence")
        commit = run_git(self.repo_dir, "rev-parse", "HEAD")
        manifest = parse_product_target_manifest(
            {
                "manifest_version": "1.0",
                "target": {
                    "source_type": "local_git",
                    "repo": str(self.repo_dir),
                    "commit": commit,
                },
                "authority_surface": {"include": ["src/**"]},
                "mode": {"read_only": True},
            }
        )
        return ProductCorpusResolver().resolve(manifest, self.repo_dir)

    def _admitted(
        self,
        rule_value: ImplementationEvidenceRule,
        expectation_specs: tuple[tuple[str, tuple[str, ...]], ...] | None = None,
    ):
        ruleset = make_admitted_ruleset(rule_value)
        expectation_set = make_admitted_expectations(
            self.policy_admission,
            ruleset.rules,
            expectation_specs=expectation_specs,
        )
        return expectation_set, ruleset


class ImplementationEvaluatorTests(EvaluatorTestBase):
    def test_file_exists_returns_one_ref_with_specified_locator(self) -> None:
        snapshot = self._snapshot({"src/package.lock": "locked\n"})
        rule_value = make_rule(selectors=["src/*.lock"])
        expectation_set, ruleset = self._admitted(rule_value)

        items = evaluate_expectation_set(expectation_set, ruleset, snapshot)

        self.assertEqual(len(items), 1)
        self.assertEqual(items[0].verdict, ImplementationEvidenceVerdict.EVIDENCE_FOUND)
        self.assertEqual(
            items[0].evidence_refs[0],
            type(items[0].evidence_refs[0])(
                repo_path="src/package.lock",
                content_digest=snapshot.get_file("src/package.lock").content_hash,
                locator=EvidenceLocator("file_existence", "src/package.lock"),
            ),
        )

    def test_empty_candidate_set_is_missing_but_not_applicable_takes_precedence(self) -> None:
        snapshot = self._snapshot({"src/readme.txt": "out of scope\n"})
        applicable, applicable_rules = self._admitted(
            make_rule(selectors=["src/*.lock"])
        )
        missing = evaluate_expectation_set(applicable, applicable_rules, snapshot)
        self.assertEqual(missing[0].verdict, ImplementationEvidenceVerdict.EVIDENCE_MISSING)
        self.assertEqual(missing[0].evidence_refs, ())
        self.assertIsNone(missing[0].discrepancy_details)

        not_applicable_rule = make_rule(
            selectors=["src/*.lock"],
            applicability={"status": "NOT_APPLICABLE", "reason": "No dependency lockfile applies."},
        )
        not_applicable, not_applicable_rules = self._admitted(not_applicable_rule)
        result = evaluate_expectation_set(not_applicable, not_applicable_rules, snapshot)
        self.assertEqual(result[0].verdict, ImplementationEvidenceVerdict.RULE_NOT_APPLICABLE)
        self.assertEqual(result[0].evidence_refs, ())
        self.assertEqual(result[0].applicability_reason, "No dependency lockfile applies.")

    def test_any_and_all_quantify_files_not_yaml_nodes(self) -> None:
        snapshot = self._snapshot(
            {
                "src/a.yml": "steps:\n  - uses: expected/action@v1\n  - uses: other/action@v1\n",
                "src/b.yml": "steps:\n  - uses: other/action@v1\n",
            }
        )
        assertion_kwargs = {
            "matcher": "YAML_PATH_EQUALS",
            "target_path": "steps[*].uses",
            "expected_value": {"kind": "STRING", "value": "expected/action@v1"},
        }
        any_set, any_rules = self._admitted(
            make_rule(selectors=["src/*.yml"], quantifier="ANY", **assertion_kwargs)
        )
        any_item = evaluate_expectation_set(any_set, any_rules, snapshot)[0]
        self.assertEqual(any_item.verdict, ImplementationEvidenceVerdict.EVIDENCE_FOUND)
        self.assertEqual([ref.repo_path for ref in any_item.evidence_refs], ["src/a.yml"])
        self.assertEqual(
            any_item.evidence_refs[0].resolved_node_paths,
            ("/steps/0/uses",),
        )

        all_set, all_rules = self._admitted(
            make_rule(selectors=["src/*.yml"], quantifier="ALL", **assertion_kwargs)
        )
        all_item = evaluate_expectation_set(all_set, all_rules, snapshot)[0]
        self.assertEqual(all_item.verdict, ImplementationEvidenceVerdict.EVIDENCE_DISCREPANCY)
        self.assertEqual([ref.repo_path for ref in all_item.evidence_refs], ["src/b.yml"])
        self.assertEqual(
            all_item.discrepancy_details,
            '[{"code":"VALUE_MISMATCH","repo_path":"src/b.yml"}]',
        )

    def test_any_failure_reports_all_candidates_with_sanitized_json(self) -> None:
        secret_a = "private-observed-value-A"
        secret_b = "private-observed-value-B"
        snapshot = self._snapshot(
            {
                "src/b.yml": f"token: {secret_b}\n",
                "src/a.yml": f"token: {secret_a}\n",
            }
        )
        rule_value = make_rule(
            selectors=["src/*.yml"],
            matcher="YAML_PATH_EQUALS",
            target_path="token",
            expected_value={"kind": "STRING", "value": "required-token"},
        )
        expectation_set, ruleset = self._admitted(rule_value)

        item = evaluate_expectation_set(expectation_set, ruleset, snapshot)[0]

        self.assertEqual(item.verdict, ImplementationEvidenceVerdict.EVIDENCE_DISCREPANCY)
        self.assertEqual(
            [ref.repo_path for ref in item.evidence_refs], ["src/a.yml", "src/b.yml"]
        )
        self.assertEqual(
            item.discrepancy_details,
            '[{"code":"VALUE_MISMATCH","repo_path":"src/a.yml"},'
            '{"code":"VALUE_MISMATCH","repo_path":"src/b.yml"}]',
        )
        self.assertNotIn(secret_a, repr(item))
        self.assertNotIn(secret_b, repr(item))
        self.assertNotIn("required-token", repr(item))

    def test_selector_union_deduplicates_and_sorts_paths(self) -> None:
        snapshot = self._snapshot(
            {"src/b.lock": "b\n", "src/a.lock": "a\n", "src/c.txt": "c\n"}
        )
        rule_value = make_rule(selectors=["src/*.lock", "src/a.*"])
        expectation_set, ruleset = self._admitted(rule_value)

        item = evaluate_expectation_set(expectation_set, ruleset, snapshot)[0]

        self.assertEqual(item.verdict, ImplementationEvidenceVerdict.EVIDENCE_FOUND)
        self.assertEqual(
            [ref.repo_path for ref in item.evidence_refs], ["src/a.lock", "src/b.lock"]
        )

    def test_each_expectation_rule_link_produces_distinct_item_without_rollup(self) -> None:
        snapshot = self._snapshot({"src/package.lock": "locked\n"})
        rule_value = make_rule(selectors=["src/*.lock"])
        expectation_set, ruleset = self._admitted(
            rule_value,
            expectation_specs=(("EXP-1", ("RULE-1",)), ("EXP-2", ("RULE-1",))),
        )

        items = evaluate_expectation_set(expectation_set, ruleset, snapshot)

        self.assertEqual(
            [(item.expectation_id, item.rule_id, item.verdict) for item in items],
            [
                ("EXP-1", "RULE-1", ImplementationEvidenceVerdict.EVIDENCE_FOUND),
                ("EXP-2", "RULE-1", ImplementationEvidenceVerdict.EVIDENCE_FOUND),
            ],
        )

    def test_selector_pattern_failure_is_not_treated_as_empty_candidate_set(self) -> None:
        snapshot = self._snapshot({"src/readme.txt": "none\n"})
        rule_value = make_rule(
            selectors=["src/[a].txt"],
            matcher="YAML_PATH_EXISTS",
            target_path="enabled..path",
        )
        with self.assertRaises(ContractInputError):
            self._admitted(rule_value)

    def test_candidate_invalid_yaml_fails_closed_not_as_discrepancy(self) -> None:
        snapshot = self._snapshot({"src/bad.yml": "token: [unterminated\n"})
        rule_value = make_rule(
            selectors=["src/*.yml"],
            matcher="YAML_PATH_EXISTS",
            target_path="token",
        )
        expectation_set, ruleset = self._admitted(rule_value)

        with self.assertRaises(EvaluatorInputError):
            evaluate_expectation_set(expectation_set, ruleset, snapshot)

    def test_evaluator_rejects_unadmitted_product_snapshot(self) -> None:
        snapshot = self._snapshot({"src/file.lock": "locked\n"})
        expectation_set, ruleset = self._admitted(make_rule())
        forged_snapshot = object.__new__(type(snapshot))

        with self.assertRaises(EvaluatorInputError):
            evaluate_expectation_set(expectation_set, ruleset, forged_snapshot)

    def test_admitted_rule_or_expectation_mutation_is_rejected_before_evaluation(self) -> None:
        snapshot = self._snapshot({"src/file.lock": "locked\n"})
        rule_value = make_rule(selectors=["src/*.lock"])
        expectation_set, ruleset = self._admitted(rule_value)
        changed_rule = replace(
            ruleset.rules[0], candidate_selectors=("src/*.txt",)
        )
        with self.assertRaises(EvaluatorInputError):
            evaluate_rule(expectation_set.expectations[0], changed_rule, snapshot)

        changed_expectation = replace(
            expectation_set.expectations[0], task_id="PS.2.1"
        )
        with self.assertRaises(EvaluatorInputError):
            evaluate_rule(changed_expectation, ruleset.rules[0], snapshot)

    def test_domain_values_reject_invalid_verdict_discrepancy_order_and_refs(self) -> None:
        with self.assertRaises(ValueError):
            ImplementationVerificationItem(
                expectation_id="EXP-1",
                expectation_digest="a" * 64,
                task_id="PW.4.4",
                rule_id="RULE-1",
                rule_digest="b" * 64,
                verdict="UNKNOWN",  # type: ignore[arg-type]
                evidence_refs=(),
            )

        with self.assertRaises(ValueError):
            ImplementationVerificationItem(
                expectation_id="EXP-1",
                expectation_digest="a" * 64,
                task_id="PW.4.4",
                rule_id="RULE-1",
                rule_digest="b" * 64,
                verdict=ImplementationEvidenceVerdict.EVIDENCE_DISCREPANCY,
                evidence_refs=(
                    EvidenceRef("src/a.yml", "c" * 64, EvidenceLocator("yaml_path", "key")),
                    EvidenceRef("src/b.yml", "d" * 64, EvidenceLocator("yaml_path", "key")),
                ),
                discrepancy_details=(
                    '[{"code":"VALUE_MISMATCH","repo_path":"src/b.yml"},'
                    '{"code":"VALUE_MISMATCH","repo_path":"src/a.yml"}]'
                ),
            )

        with self.assertRaises(ValueError):
            EvidenceRef("src/../outside.yml", "c" * 64, EvidenceLocator("yaml_path", "key"))
        with self.assertRaises(ValueError):
            EvidenceRef("src/./file.yml", "c" * 64, EvidenceLocator("yaml_path", "key"))
        with self.assertRaises(ValueError):
            EvidenceRef(
                "src/file.yml",
                "c" * 64,
                EvidenceLocator("yaml_path", "key"),
                resolved_node_paths=("jobs.steps",),
            )

        with self.assertRaises(ValueError):
            EvidenceRef(
                "src/file.yml",
                "c" * 64,
                EvidenceLocator("file_existence", "src/other.yml"),
            )
        with self.assertRaises(ValueError):
            EvidenceRef(
                "src/file.json",
                "c" * 64,
                EvidenceLocator("json_pointer", "value"),
            )

    def test_replaced_snapshot_and_admitted_aggregates_fail_integrity_checks(self) -> None:
        snapshot = self._snapshot({"src/file.lock": "locked\n"})
        expectation_set, ruleset = self._admitted(make_rule())
        file = snapshot.get_file("src/file.lock")
        altered_file = replace(file, content="secret altered content\n")
        with self.assertRaises(CorpusResolverError):
            replace(snapshot, files=(altered_file,))
        with self.assertRaises(CorpusResolverError):
            replace(snapshot, files=[file])

        mutable_snapshot = object.__new__(type(snapshot))
        for field_name in snapshot.__dataclass_fields__:
            object.__setattr__(mutable_snapshot, field_name, getattr(snapshot, field_name))
        object.__setattr__(mutable_snapshot, "files", [file])
        with self.assertRaises(EvaluatorInputError):
            evaluate_expectation_set(expectation_set, ruleset, mutable_snapshot)

        changed_rule = replace(ruleset.rules[0], candidate_selectors=("src/*.txt",))
        changed_ruleset = replace(ruleset, rules=(changed_rule,))
        with self.assertRaises(EvaluatorInputError):
            evaluate_expectation_set(expectation_set, changed_ruleset, snapshot)

        changed_expectation = replace(
            expectation_set.expectations[0], policy_source_ref="policy/other.md#sec"
        )
        changed_set = replace(expectation_set, expectations=(changed_expectation,))
        with self.assertRaises(EvaluatorInputError):
            evaluate_expectation_set(changed_set, ruleset, snapshot)


if __name__ == "__main__":
    unittest.main()
