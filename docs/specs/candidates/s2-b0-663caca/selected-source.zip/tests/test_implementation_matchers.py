from __future__ import annotations

import unittest

from tools.implementation_matchers import (
    DiscrepancyCode,
    EvidenceAssertion,
    ExpectedScalar,
    ExpectedScalarKind,
    InvalidEvidenceInputError,
    InvalidRuleError,
    MatcherKind,
    evaluate_assertion,
)


class ImplementationMatcherTests(unittest.TestCase):
    def _expected(self, kind: ExpectedScalarKind, value: str | bool | int | None):
        return ExpectedScalar(kind=kind, value=value)

    def _equals(self, matcher: MatcherKind, path: str, kind: ExpectedScalarKind, value):
        return EvidenceAssertion(
            matcher=matcher,
            target_path_expression=path,
            expected_value=self._expected(kind, value),
        )

    def test_file_exists_matcher_has_no_structured_locator(self) -> None:
        result = evaluate_assertion(
            EvidenceAssertion(MatcherKind.FILE_EXISTS), "content is not parsed"
        )

        self.assertTrue(result.passed)
        self.assertEqual(result.resolved_node_paths, ())
        self.assertIsNone(result.discrepancy_code)

    def test_expected_scalar_rejects_python_bool_as_integer(self) -> None:
        with self.assertRaises(InvalidRuleError):
            ExpectedScalar(ExpectedScalarKind.INTEGER, True)

    def test_matcher_field_combinations_are_fail_closed(self) -> None:
        invalid_assertions = (
            lambda: EvidenceAssertion(
                MatcherKind.FILE_EXISTS, target_path_expression="src/**"
            ),
            lambda: EvidenceAssertion(
                MatcherKind.YAML_PATH_EXISTS,
                target_path_expression="security.enabled",
                expected_value=self._expected(ExpectedScalarKind.BOOLEAN, True),
            ),
            lambda: EvidenceAssertion(
                MatcherKind.JSON_POINTER_EQUALS, target_path_expression="/enabled"
            ),
        )
        for create_assertion in invalid_assertions:
            with self.subTest(create_assertion=create_assertion):
                with self.assertRaises(InvalidRuleError):
                    create_assertion()

    def test_yaml_path_wildcard_returns_only_matching_concrete_nodes(self) -> None:
        assertion = self._equals(
            MatcherKind.YAML_PATH_EQUALS,
            "jobs.security.steps[*].uses",
            ExpectedScalarKind.STRING,
            "sigstore/cosign-installer@v3",
        )

        result = evaluate_assertion(
            assertion,
            "jobs:\n  security:\n    steps:\n"
            "      - uses: actions/checkout@v4\n"
            "      - uses: sigstore/cosign-installer@v3\n",
        )

        self.assertTrue(result.passed)
        self.assertEqual(
            result.resolved_node_paths,
            ("/jobs/security/steps/1/uses",),
        )

    def test_yaml_path_exists_accepts_uncomparable_value_and_equals_does_not(self) -> None:
        content = "release:\n  date: 2026-01-01\n"
        exists = evaluate_assertion(
            EvidenceAssertion(
                MatcherKind.YAML_PATH_EXISTS,
                target_path_expression="release.date",
            ),
            content,
        )
        equals = evaluate_assertion(
            self._equals(
                MatcherKind.YAML_PATH_EQUALS,
                "release.date",
                ExpectedScalarKind.STRING,
                "2026-01-01",
            ),
            content,
        )

        self.assertTrue(exists.passed)
        self.assertEqual(exists.resolved_node_paths, ("/release/date",))
        self.assertFalse(equals.passed)
        self.assertEqual(equals.discrepancy_code, DiscrepancyCode.UNCOMPARABLE_NODE)

    def test_yaml_uses_yaml_12_boolean_resolution(self) -> None:
        assertion = self._equals(
            MatcherKind.YAML_PATH_EQUALS,
            "legacy_flag",
            ExpectedScalarKind.STRING,
            "yes",
        )

        result = evaluate_assertion(assertion, "legacy_flag: yes\n")

        self.assertTrue(result.passed)
        self.assertEqual(result.resolved_node_paths, ("/legacy_flag",))

    def test_yaml_integer_core_forms_are_compared_numerically(self) -> None:
        for source, expected in (
            ("0b1010", 10),
            ("0o10", 8),
            ("0x10", 16),
            ("1_000", 1000),
        ):
            with self.subTest(source=source):
                assertion = self._equals(
                    MatcherKind.YAML_PATH_EQUALS,
                    "value",
                    ExpectedScalarKind.INTEGER,
                    expected,
                )
                self.assertTrue(evaluate_assertion(assertion, f"value: {source}\n").passed)

        leading_zero = evaluate_assertion(
            self._equals(
                MatcherKind.YAML_PATH_EQUALS,
                "value",
                ExpectedScalarKind.INTEGER,
                12,
            ),
            "value: 012\n",
        )
        self.assertEqual(
            leading_zero.discrepancy_code, DiscrepancyCode.VALUE_MISMATCH
        )

    def test_yaml_empty_path_targets_document_root(self) -> None:
        result = evaluate_assertion(
            self._equals(
                MatcherKind.YAML_PATH_EQUALS,
                "",
                ExpectedScalarKind.NULL,
                None,
            ),
            "",
        )

        self.assertTrue(result.passed)
        self.assertEqual(result.resolved_node_paths, ("",))

    def test_yaml_path_rejects_unsupported_and_malformed_tokens(self) -> None:
        invalid_paths = (
            "jobs..steps",
            "jobs.steps[01]",
            "jobs.steps['first']",
            "jobs.steps[?(@.name)]",
            "jobs.steps.",
            "jobs.steps]",
            "jobs.steps\\name",
        )
        for path in invalid_paths:
            with self.subTest(path=path):
                assertion = EvidenceAssertion(
                    MatcherKind.YAML_PATH_EXISTS, target_path_expression=path
                )
                with self.assertRaises(InvalidRuleError):
                    evaluate_assertion(assertion, "jobs: {}\n")

    def test_json_pointer_decodes_escaped_keys_and_reports_canonical_node_path(self) -> None:
        assertion = self._equals(
            MatcherKind.JSON_POINTER_EQUALS,
            "/a~1b/~0key",
            ExpectedScalarKind.STRING,
            "matched",
        )

        result = evaluate_assertion(assertion, '{"a/b": {"~key": "matched"}}')

        self.assertTrue(result.passed)
        self.assertEqual(result.resolved_node_paths, ("/a~1b/~0key",))

    def test_json_pointer_array_index_requires_canonical_index(self) -> None:
        assertion = self._equals(
            MatcherKind.JSON_POINTER_EQUALS,
            "/steps/1/name",
            ExpectedScalarKind.STRING,
            "sign",
        )
        result = evaluate_assertion(assertion, '{"steps": [{}, {"name": "sign"}]}')
        self.assertTrue(result.passed)
        self.assertEqual(result.resolved_node_paths, ("/steps/1/name",))

        noncanonical = EvidenceAssertion(
            MatcherKind.JSON_POINTER_EXISTS, target_path_expression="/steps/01"
        )
        self.assertEqual(
            evaluate_assertion(noncanonical, '{"steps": [{}, {"name": "sign"}]}').discrepancy_code,
            DiscrepancyCode.NO_NODE_MATCH,
        )

    def test_json_pointer_invalid_escape_is_an_invalid_rule(self) -> None:
        assertion = EvidenceAssertion(
            MatcherKind.JSON_POINTER_EXISTS, target_path_expression="/a~2b"
        )

        with self.assertRaises(InvalidRuleError):
            evaluate_assertion(assertion, '{"a~2b": true}')

    def test_mismatch_result_contains_no_expected_or_observed_value(self) -> None:
        secret = "raw-token-should-never-appear"
        assertion = self._equals(
            MatcherKind.JSON_POINTER_EQUALS,
            "/credential",
            ExpectedScalarKind.STRING,
            "expected-value",
        )

        result = evaluate_assertion(assertion, f'{{"credential": "{secret}"}}')

        self.assertEqual(result.discrepancy_code, DiscrepancyCode.VALUE_MISMATCH)
        self.assertNotIn(secret, repr(result))
        self.assertNotIn("expected-value", repr(result))

    def test_yaml_duplicate_keys_multiple_documents_custom_tag_and_recursive_alias_fail(self) -> None:
        invalid_documents = (
            "credential: first\ncredential: second\n",
            "value: one\n---\nvalue: two\n",
            "value: !private secret\n",
            "value: &loop [*loop]\n",
        )
        assertion = EvidenceAssertion(
            MatcherKind.YAML_PATH_EXISTS, target_path_expression="credential"
        )
        for content in invalid_documents:
            with self.subTest(content=content):
                with self.assertRaises(InvalidEvidenceInputError) as context:
                    evaluate_assertion(assertion, content)
                self.assertNotIn("secret", str(context.exception))

    def test_json_duplicate_keys_non_rfc_constant_and_unpaired_surrogate_fail(self) -> None:
        invalid_documents = (
            '{"credential": "first", "credential": "second"}',
            '{"value": NaN}',
            '{"value": "\\ud800"}',
        )
        assertion = EvidenceAssertion(
            MatcherKind.JSON_POINTER_EXISTS, target_path_expression="/credential"
        )
        for content in invalid_documents:
            with self.subTest(content=content):
                with self.assertRaises(InvalidEvidenceInputError):
                    evaluate_assertion(assertion, content)

    def test_yaml_equals_mismatch_reports_all_evaluated_nodes_without_values(self) -> None:
        assertion = self._equals(
            MatcherKind.YAML_PATH_EQUALS,
            "values[*]",
            ExpectedScalarKind.STRING,
            "expected",
        )

        result = evaluate_assertion(assertion, "values:\n  - secret-one\n  - secret-two\n")

        self.assertFalse(result.passed)
        self.assertEqual(result.discrepancy_code, DiscrepancyCode.VALUE_MISMATCH)
        self.assertEqual(result.resolved_node_paths, ("/values/0", "/values/1"))
        self.assertNotIn("secret-one", repr(result))
        self.assertNotIn("secret-two", repr(result))


if __name__ == "__main__":
    unittest.main()