from __future__ import annotations

import os
import subprocess
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from tools.product_corpus_resolver import (
    CorpusResolverError,
    ProductCorpusResolver,
    resolve_product_corpus_from_manifest,
)
from tools.repo_corpus_resolver import RepoCorpusResolver
from tools.validate_product_target_manifest import parse_product_target_manifest


def run_git(args: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=cwd,
        capture_output=True,
        text=True,
        check=True,
        encoding="utf-8",
    )


class StaticGitClient:
    def verify_commit_exists(self, repo_path: Path, commit: str) -> bool:
        return True

    def get_remote_url(self, repo_path: Path, remote_name: str = "origin") -> str | None:
        return None

    def list_tree_entries(self, repo_path: Path, commit: str) -> list[tuple[str, str, str, str]]:
        return [
            ("100644", "blob", "a" * 40, "src/real.yml"),
            ("120000", "blob", "b" * 40, "src/linked.yml"),
        ]

    def read_blob_bytes(self, repo_path: Path, commit: str, rel_path: str) -> bytes:
        return b"value: real\n"


class ProductCorpusResolverTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = TemporaryDirectory()
        self.repo_dir = Path(self.temp_dir.name)
        run_git(["init", "-b", "main"], cwd=self.repo_dir)
        run_git(["config", "user.name", "S2 Test Assessor"], cwd=self.repo_dir)
        run_git(["config", "user.email", "s2-test@example.invalid"], cwd=self.repo_dir)

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def _commit_files(self, files: dict[str, str | bytes], message: str) -> str:
        for relative_path, content in files.items():
            path = self.repo_dir / relative_path
            path.parent.mkdir(parents=True, exist_ok=True)
            if isinstance(content, str):
                path.write_text(content, encoding="utf-8")
            else:
                path.write_bytes(content)
        run_git(["add", "."], cwd=self.repo_dir)
        run_git(["commit", "-m", message], cwd=self.repo_dir)
        return run_git(["rev-parse", "HEAD"], cwd=self.repo_dir).stdout.strip()

    def _manifest(self, commit: str, include: list[str], exclude: list[str] | None = None):
        authority_surface = {"include": include}
        if exclude is not None:
            authority_surface["exclude"] = exclude
        return parse_product_target_manifest(
            {
                "manifest_version": "1.0",
                "target": {
                    "source_type": "local_git",
                    "repo": str(self.repo_dir),
                    "commit": commit,
                },
                "authority_surface": authority_surface,
                "mode": {"read_only": True},
            }
        )

    def test_snapshot_uses_fixed_commit_and_spec_golden_digests(self) -> None:
        first_commit = self._commit_files({"src/app.yml": "value: one\n"}, "first")
        second_commit = self._commit_files({"src/app.yml": "value: two\n"}, "second")
        manifest = self._manifest(first_commit, ["src/**"])
        status_before = run_git(
            ["status", "--porcelain", "--untracked-files=all"], cwd=self.repo_dir
        ).stdout

        snapshot = ProductCorpusResolver().resolve(manifest, self.repo_dir)

        self.assertEqual(snapshot.target_commit, first_commit)
        self.assertEqual(
            run_git(["rev-parse", "HEAD"], cwd=self.repo_dir).stdout.strip(),
            second_commit,
        )
        self.assertEqual(
            run_git(["status", "--porcelain", "--untracked-files=all"], cwd=self.repo_dir).stdout,
            status_before,
        )
        self.assertEqual(snapshot.paths(), ("src/app.yml",))
        self.assertEqual(snapshot.get_file("src/app.yml").content, "value: one\n")
        self.assertEqual(
            snapshot.get_file("src/app.yml").content_hash,
            "549aa4d1f1772ca92d96a87e26660b2674dfaa167b926d9ce38a6f3a8d37b853",
        )
        self.assertEqual(
            snapshot.corpus_digest,
            "0dcabde8356d38ccb34e2233c81d38ab1ae96d69ae2fa3f45e841bcc75307e04",
        )
        self.assertEqual(snapshot.manifest_digest, manifest.digest)

    def test_exclude_always_wins_for_product_authority_surface(self) -> None:
        commit = self._commit_files(
            {"src/app.yml": "app\n", "src/generated/build.yml": "generated\n"},
            "authority files",
        )

        snapshot = ProductCorpusResolver().resolve(
            self._manifest(commit, ["src/**"], ["src/generated/**"]), self.repo_dir
        )

        self.assertEqual(snapshot.paths(), ("src/app.yml",))

    def test_symlink_is_skipped_from_product_evidence_snapshot(self) -> None:
        self._commit_files({"src/real.yml": "value: real\n"}, "regular file")
        link = self.repo_dir / "src" / "linked.yml"
        try:
            os.symlink("real.yml", link)
        except (OSError, NotImplementedError):
            self.skipTest("The current Windows account cannot create Git symlinks")
        run_git(["add", "src/linked.yml"], cwd=self.repo_dir)
        run_git(["commit", "-m", "symlink"], cwd=self.repo_dir)
        commit = run_git(["rev-parse", "HEAD"], cwd=self.repo_dir).stdout.strip()

        snapshot = ProductCorpusResolver().resolve(
            self._manifest(commit, ["src/**"]), self.repo_dir
        )

        self.assertEqual(snapshot.paths(), ("src/real.yml",))

    def test_git_symlink_mode_is_skipped_without_os_symlink_support(self) -> None:
        manifest = self._manifest("a" * 40, ["src/**"])
        resolver = ProductCorpusResolver(RepoCorpusResolver(git_client=StaticGitClient()))

        snapshot = resolver.resolve(manifest, self.repo_dir)

        self.assertEqual(snapshot.paths(), ("src/real.yml",))

    def test_empty_product_corpus_fails_closed(self) -> None:
        commit = self._commit_files({"docs/readme.md": "not in scope\n"}, "out of scope")

        with self.assertRaises(CorpusResolverError):
            ProductCorpusResolver().resolve(
                self._manifest(commit, ["src/**"]), self.repo_dir
            )

    def test_github_source_requires_matching_local_origin(self) -> None:
        commit = self._commit_files({"src/app.yml": "value: one\n"}, "source")
        manifest = parse_product_target_manifest(
            {
                "manifest_version": "1.0",
                "target": {
                    "source_type": "github",
                    "repo": "example/product",
                    "commit": commit,
                },
                "authority_surface": {"include": ["src/**"]},
                "mode": {"read_only": True},
            }
        )

        with self.assertRaises(CorpusResolverError):
            ProductCorpusResolver().resolve(manifest, self.repo_dir)

    def test_local_repo_path_override_cannot_change_declared_target(self) -> None:
        commit = self._commit_files({"src/app.yml": "value: one\n"}, "source")
        manifest = self._manifest(commit, ["src/**"])
        different_repo = self.repo_dir.parent / f"{self.repo_dir.name}-different"
        different_repo.mkdir()
        try:
            with self.assertRaises(CorpusResolverError):
                ProductCorpusResolver().resolve(manifest, different_repo)
        finally:
            different_repo.rmdir()

    def test_file_entrypoint_admits_manifest_before_resolving(self) -> None:
        commit = self._commit_files({"src/app.yml": "value: one\n"}, "source")
        manifest_path = self.repo_dir.parent / f"{self.repo_dir.name}-manifest.yaml"
        manifest_path.write_text(
            "\n".join(
                (
                    'manifest_version: "1.0"',
                    "target:",
                    "  source_type: local_git",
                    f"  repo: {self.repo_dir.as_posix()}",
                    f"  commit: {commit}",
                    "authority_surface:",
                    "  include:",
                    "    - src/**",
                    "mode:",
                    "  read_only: true",
                    "",
                )
            ),
            encoding="utf-8",
        )
        try:
            snapshot = resolve_product_corpus_from_manifest(manifest_path, self.repo_dir)
        finally:
            manifest_path.unlink(missing_ok=True)

        self.assertEqual(snapshot.paths(), ("src/app.yml",))


if __name__ == "__main__":
    unittest.main()